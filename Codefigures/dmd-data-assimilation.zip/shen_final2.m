syms x y v w 
eqn1 = v;
eqn2 = w;
eqn3 = -x-2*x*y;
eqn4 = -y-x^2+y^2;
eqns = [eqn1==0,eqn2==0,eqn3==0,eqn4==0];
vars = [x,y,v,w];
[solx,soly,solv,solw] = solve(eqns,vars);
xe = double(solx)
ye = double(soly)
ve = double(solv)
we = double(solw)
J = jacobian([eqn1,eqn2,eqn3,eqn4],[x,y,v,w])
[xe(1),ye(1),ve(1),we(1)];
Jeq1 = subs(J,[x,y,v,w],[xe(1),ye(1),ve(1),we(1)]);
Jeq2 = subs(J,[x,y,v,w],[xe(2),ye(2),ve(2),we(2)]);
Jeq3 = subs(J,[x,y,v,w],[xe(3),ye(3),ve(3),we(3)]);
Jeq4 = subs(J,[x,y,v,w],[xe(4),ye(4),ve(4),we(4)]);
Jeq1 = double(Jeq1)
Jeq2 = double(Jeq2)
Jeq3 = double(Jeq3)
Jeq4 = double(Jeq4)
[l,m] = eig(Jeq1)
[n,o] = eig(Jeq2)
[p,q] = eig(Jeq3)
[r,s] = eig(Jeq4)
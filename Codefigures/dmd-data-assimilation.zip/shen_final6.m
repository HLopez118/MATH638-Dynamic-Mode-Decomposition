%code used to check answers to problem 6 for the dissipative part
clc
clear
syms x y z y1 z1 s r b d x0 l
s=10;
r=28;
b=8/3;
d=19/3;
eqn1 = -s*x + s*y;
eqn2 = -x*z + r*x -y;
eqn3 = x*y -x*y1 -b*z;
eqn4 = x*z -2*x*z1 -d*y1;
eqn5 = 2*x*y1 -4*b*z1;
eqns = [eqn1==0,eqn2==0,eqn3==0,eqn4==0,eqn5==0];
vars = [x,y,z,y1,z1];
[solx,soly,solz,soly1,solz1] = solve(eqns,vars);
xc = double(solx)
yc = double(soly)
zc = double(solz)
y1c = double(soly1)
z1c = double(solz1)
J = jacobian([eqn1,eqn2,eqn3,eqn4,eqn5],[x,y,z,y1,z1])
Jc = subs(J,[x,y,z,y1,z1],[0,0,0,0,0]); %trivial critical point